<?php
/**
 * AI-Core Settings Class
 * 
 * Handles plugin settings management using WordPress Settings API
 * 
 * @package AI_Core
 * @version 0.7.3
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI-Core Settings Class
 * 
 * Manages plugin settings and configuration
 */
class AI_Core_Settings {

    /**
     * Option name holding every AI-Core setting
     *
     * Declared as a constant as well as a property so the encryption hooks,
     * which run outside any instance, can reference it.
     *
     * @var string
     */
    const OPTION_NAME = 'ai_core_settings';

    /**
     * Versioned marker prefixed to every encrypted value at rest
     *
     * @var string
     */
    const ENCRYPTION_PREFIX = 'aicenc1:';

    /**
     * Option recording which storage format the keys are in
     *
     * @var string
     */
    const ENCRYPTION_OPTION = 'ai_core_key_storage_version';

    /**
     * Current storage format version
     *
     * @var string
     */
    const ENCRYPTION_VERSION = '1';

    /**
     * Sentinel that asks sanitize_settings() to erase a stored key
     *
     * A blank field and a deliberate clear are two different intentions, and
     * only one of them may delete a key. See sanitize_settings().
     *
     * @var string
     */
    const CLEAR_SENTINEL = '__ai_core_clear_key__';

    /**
     * Class instance
     *
     * @var AI_Core_Settings
     */
    private static $instance = null;

    /**
     * Settings group name
     * 
     * @var string
     */
    private $settings_group = 'ai_core_settings_group';
    
    /**
     * Settings page slug
     * 
     * @var string
     */
    private $settings_page = 'ai-core-settings';
    
    /**
     * Option name
     * 
     * @var string
     */
    private $option_name = self::OPTION_NAME;

    /**
     * Setting keys that hold a secret and are encrypted at rest
     *
     * @return array
     */
    private static function get_secret_fields() {
        return array(
            'openai_api_key',
            'anthropic_api_key',
            'gemini_api_key',
            'grok_api_key',
        );
    }

    /**
     * Get class instance
     * 
     * @return AI_Core_Settings
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize settings
     *
     * @return void
     */
    private function init() {
        // Register settings immediately since this is already called in admin_init
        $this->register_settings();
    }
    
    /**
     * Register plugin settings
     *
     * @return void
     */
    public function register_settings() {
        // Register settings
        register_setting(
            $this->settings_group,
            $this->option_name,
            array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize_settings'),
                'default' => $this->get_default_settings(),
                'show_in_rest' => false
            )
        );

        // Add settings sections
        $this->add_settings_sections();

        // Add settings fields
        $this->add_settings_fields();
    }
    
    /**
     * Add settings sections
     * 
     * @return void
     */
    private function add_settings_sections() {
        // API Keys Section
        add_settings_section(
            'ai_core_api_keys_section',
            __('API Keys Configuration', 'ai-core'),
            array($this, 'api_keys_section_callback'),
            $this->settings_page
        );

        // Provider Configuration Section
        add_settings_section(
            'ai_core_provider_section',
            __('Provider Configuration', 'ai-core'),
            array($this, 'provider_section_callback'),
            $this->settings_page
        );
        
        // General Settings Section
        add_settings_section(
            'ai_core_general_section',
            __('General Settings', 'ai-core'),
            array($this, 'general_section_callback'),
            $this->settings_page
        );

        // Test Prompt Section
        add_settings_section(
            'ai_core_test_prompt_section',
            __('Test Prompt', 'ai-core'),
            array($this, 'test_prompt_section_callback'),
            $this->settings_page
        );
    }
    
    /**
     * Add settings fields
     *
     * @return void
     */
    private function add_settings_fields() {
        // OpenAI API Key
        add_settings_field(
            'openai_api_key',
            __('OpenAI API Key', 'ai-core'),
            array($this, 'api_key_field_callback'),
            $this->settings_page,
            'ai_core_api_keys_section',
            array('provider' => 'openai', 'label' => 'OpenAI')
        );
        
        // Anthropic API Key
        add_settings_field(
            'anthropic_api_key',
            __('Anthropic API Key', 'ai-core'),
            array($this, 'api_key_field_callback'),
            $this->settings_page,
            'ai_core_api_keys_section',
            array('provider' => 'anthropic', 'label' => 'Anthropic Claude')
        );
        
        // Gemini API Key
        add_settings_field(
            'gemini_api_key',
            __('Google Gemini API Key', 'ai-core'),
            array($this, 'api_key_field_callback'),
            $this->settings_page,
            'ai_core_api_keys_section',
            array('provider' => 'gemini', 'label' => 'Google Gemini')
        );
        
        // Grok API Key
        add_settings_field(
            'grok_api_key',
            __('xAI Grok API Key', 'ai-core'),
            array($this, 'api_key_field_callback'),
            $this->settings_page,
            'ai_core_api_keys_section',
            array('provider' => 'grok', 'label' => 'xAI Grok')
        );

        // Provider defaults configuration
        add_settings_field(
            'provider_defaults',
            __('Provider Defaults', 'ai-core'),
            array($this, 'provider_settings_field_callback'),
            $this->settings_page,
            'ai_core_provider_section'
        );
        
        // Default Provider
        add_settings_field(
            'default_provider',
            __('Default Provider', 'ai-core'),
            array($this, 'default_provider_field_callback'),
            $this->settings_page,
            'ai_core_general_section'
        );
        
        // Enable Stats
        add_settings_field(
            'enable_stats',
            __('Enable Usage Statistics', 'ai-core'),
            array($this, 'checkbox_field_callback'),
            $this->settings_page,
            'ai_core_general_section',
            array('field' => 'enable_stats', 'label' => 'Track API usage statistics')
        );
        
        // Enable Caching
        add_settings_field(
            'enable_caching',
            __('Enable Model Caching', 'ai-core'),
            array($this, 'checkbox_field_callback'),
            $this->settings_page,
            'ai_core_general_section',
            array('field' => 'enable_caching', 'label' => 'Cache available models list')
        );

        // Persist Settings on Uninstall
        add_settings_field(
            'persist_on_uninstall',
            __('Persist Settings on Uninstall', 'ai-core'),
            array($this, 'checkbox_field_callback'),
            $this->settings_page,
            'ai_core_general_section',
            array('field' => 'persist_on_uninstall', 'label' => 'Keep API keys and settings when plugin is deleted (recommended)')
        );

        // Test Prompt Field
        add_settings_field(
            'test_prompt',
            '',
            array($this, 'test_prompt_field_callback'),
            $this->settings_page,
            'ai_core_test_prompt_section'
        );
    }
    
    /**
     * API keys section callback
     *
     * @return void
     */
    public function api_keys_section_callback() {
        echo '<p>' . esc_html__('Configure your AI provider API keys. At least one API key is required for the plugin to function.', 'ai-core') . '</p>';
        echo '<p style="background: #f0f6fc; border-left: 4px solid #2271b1; padding: 12px; margin: 16px 0;">';
        echo '<span class="dashicons dashicons-info" style="color: #2271b1;"></span> ';
        echo '<strong>' . esc_html__('Auto-Validation:', 'ai-core') . '</strong> ';
        echo esc_html__('API keys are automatically validated and saved when you paste them. No need to click a "Test" button!', 'ai-core');
        echo '</p>';
    }

    /**
     * Provider section callback
     *
     * @return void
     */
    public function provider_section_callback() {
        echo '<p>' . esc_html__('Choose default models and tuning options for each provider. These settings are applied across all AI-Core integrations.', 'ai-core') . '</p>';
    }
    
    /**
     * General section callback
     *
     * @return void
     */
    public function general_section_callback() {
        echo '<p>' . esc_html__('Configure general plugin settings.', 'ai-core') . '</p>';
    }

    /**
     * Test prompt section callback
     *
     * @return void
     */
    public function test_prompt_section_callback() {
        echo '<p>' . esc_html__('Test your AI providers with a prompt. You can load saved prompts from the Prompt Library.', 'ai-core') . '</p>';
    }

    /**
     * Test prompt field callback
     *
     * @return void
     */
    public function test_prompt_field_callback() {
        ?>
        <div class="ai-core-test-prompt-wrapper">
            <div class="ai-core-prompt-loader">
                <label for="ai-core-load-prompt"><?php esc_html_e('Load from Library:', 'ai-core'); ?></label>
                <select id="ai-core-load-prompt" class="regular-text">
                    <option value=""><?php esc_html_e('-- Select a prompt --', 'ai-core'); ?></option>
                </select>
                <button type="button" class="button" id="ai-core-refresh-prompts">
                    <span class="dashicons dashicons-update"></span>
                    <?php esc_html_e('Refresh', 'ai-core'); ?>
                </button>
            </div>

            <div class="ai-core-test-prompt-form">
                <textarea id="ai-core-test-prompt-content" rows="6" class="large-text" placeholder="<?php esc_attr_e('Enter your test prompt here...', 'ai-core'); ?>"></textarea>

                <div class="ai-core-test-prompt-options">
                    <label for="ai-core-test-provider"><?php esc_html_e('Provider:', 'ai-core'); ?></label>
                    <select id="ai-core-test-provider">
                        <option value=""><?php esc_html_e('-- Select Provider --', 'ai-core'); ?></option>
                        <?php
                        // Only show configured providers
                        $api = AI_Core_API::get_instance();
                        $configured_providers = $api->get_configured_providers();
                        $provider_names = array(
                            'openai' => 'OpenAI',
                            'anthropic' => 'Anthropic Claude',
                            'gemini' => 'Google Gemini',
                            'grok' => 'xAI Grok'
                        );
                        foreach ($configured_providers as $provider) {
                            echo '<option value="' . esc_attr($provider) . '">' . esc_html($provider_names[$provider] ?? $provider) . '</option>';
                        }
                        ?>
                    </select>

                    <label for="ai-core-test-model"><?php esc_html_e('Model:', 'ai-core'); ?></label>
                    <select id="ai-core-test-model">
                        <option value=""><?php esc_html_e('-- Select Provider First --', 'ai-core'); ?></option>
                    </select>

                    <label for="ai-core-test-type"><?php esc_html_e('Type:', 'ai-core'); ?></label>
                    <select id="ai-core-test-type">
                        <option value="text"><?php esc_html_e('Text Generation', 'ai-core'); ?></option>
                        <option value="image"><?php esc_html_e('Image Generation', 'ai-core'); ?></option>
                    </select>

                    <button type="button" class="button button-primary" id="ai-core-run-test-prompt">
                        <span class="dashicons dashicons-controls-play"></span>
                        <?php esc_html_e('Run Prompt', 'ai-core'); ?>
                    </button>
                </div>

                <div id="ai-core-test-prompt-result" class="ai-core-test-prompt-result" style="display: none;"></div>
            </div>
        </div>
        <?php
    }
    
    /**
     * API key field callback
     *
     * @param array $args Field arguments
     * @return void
     */
    public function api_key_field_callback($args) {
        $settings = get_option($this->option_name, $this->get_default_settings());
        $provider = $args['provider'];
        $field_name = $provider . '_api_key';
        $value = $settings[$field_name] ?? '';
        $has_saved_key = !empty($value);

        // Masked hint only. The key itself is never written into the markup,
        // so the browser has no copy of it and view-source shows nothing.
        $masked_hint = $has_saved_key
            ? '••••••••••••••••••••' . substr($value, -4)
            : __('Enter your API key', 'ai-core');

        echo '<div class="ai-core-api-key-field" data-provider="' . esc_attr($provider) . '" data-has-saved="' . ($has_saved_key ? '1' : '0') . '">';

        // Visible input field. Always empty on render: it accepts a new key,
        // it never displays the stored one.
        echo '<input type="password" ';
        echo 'id="' . esc_attr($field_name) . '" ';
        echo 'name="' . esc_attr($this->option_name) . '[' . esc_attr($field_name) . ']" ';
        echo 'value="" ';
        echo 'class="regular-text ai-core-api-key-input" ';
        echo 'autocomplete="new-password" ';
        echo 'spellcheck="false" ';
        echo 'autocapitalize="off" ';
        echo 'autocorrect="off" ';
        echo 'aria-label="' . esc_attr(sprintf(__('%s API key', 'ai-core'), $args['label'])) . '" ';
        echo 'data-has-saved="' . ($has_saved_key ? '1' : '0') . '" ';
        echo 'data-provider="' . esc_attr($provider) . '" ';
        echo 'placeholder="' . esc_attr($masked_hint) . '" />';

        echo '<button type="button" class="button ai-core-test-key" data-provider="' . esc_attr($provider) . '">';
        echo esc_html__('Test Key', 'ai-core');
        echo '</button>';

        echo '<button type="button" class="button ai-core-refresh-models" data-provider="' . esc_attr($provider) . '"' . ($has_saved_key ? '' : ' disabled') . '>';
        echo esc_html__('Refresh Models', 'ai-core');
        echo '</button>';

        if ($has_saved_key) {
            echo '<button type="button" class="button ai-core-clear-key" data-field="' . esc_attr($field_name) . '">';
            echo esc_html__('Clear', 'ai-core');
            echo '</button>';
        }

        echo '<span class="ai-core-key-status" id="' . esc_attr($provider) . '-status"></span>';
        echo '</div>';

        if ($has_saved_key) {
            echo '<p class="description" style="color: #2271b1;">';
            echo '<span class="dashicons dashicons-yes-alt"></span> ';
            echo esc_html__('API key validated and saved automatically. Use Test Key anytime to re-verify.', 'ai-core');
            echo '</p>';
        } else {
            echo '<p class="description">';
            printf(
                esc_html__('Paste your %s API key. Validation runs automatically and you can click Test Key to confirm manually.', 'ai-core'),
                esc_html($args['label'])
            );
            echo '</p>';
        }
    }

    /**
     * Provider settings field callback
     *
     * @return void
     */
    public function provider_settings_field_callback() {
        $settings = get_option($this->option_name, $this->get_default_settings());
        $provider_models = $settings['provider_models'] ?? array();
        $provider_options = $settings['provider_options'] ?? array();

        $providers = array(
            'openai' => 'OpenAI',
            'anthropic' => 'Anthropic Claude',
            'gemini' => 'Google Gemini',
            'grok' => 'xAI Grok'
        );

        $api = AI_Core_API::get_instance();

        echo '<div class="ai-core-provider-grid">';

        foreach ($providers as $key => $label) {
            $has_key = !empty($settings[$key . '_api_key']);
            $models = $has_key ? $api->get_available_models($key) : array();
            $selected_model = $provider_models[$key] ?? '';
            $options = $provider_options[$key] ?? array();

            echo '<div class="ai-core-provider-card" data-provider="' . esc_attr($key) . '" data-has-key="' . ($has_key ? '1' : '0') . '">';
            echo '<div class="ai-core-provider-card__header">';
            echo '<h4>' . esc_html($label) . '</h4>';
            echo '<span class="ai-core-provider-status ' . ($has_key ? 'is-active' : 'is-inactive') . '">';
            echo esc_html($has_key ? __('Connected', 'ai-core') : __('Awaiting API Key', 'ai-core'));
            echo '</span>';
            echo '</div>';

            echo '<div class="ai-core-provider-card__body">';

            $model_field_id = 'ai-core-provider-model-' . $key;

            echo '<label for="' . esc_attr($model_field_id) . '">' . esc_html__('Default Model', 'ai-core') . '</label>';
            // aria-label repeats the visible label text and adds the provider,
            // so the four cards do not present four identical names.
            echo '<select id="' . esc_attr($model_field_id) . '" class="ai-core-provider-model" aria-label="' . esc_attr(sprintf(__('%s default model', 'ai-core'), $label)) . '" data-provider="' . esc_attr($key) . '" name="' . esc_attr($this->option_name) . '[provider_models][' . esc_attr($key) . ']" ' . ($has_key ? '' : 'disabled') . '>';

            if (!$has_key) {
                echo '<option value="">' . esc_html__('Add an API key to load models', 'ai-core') . '</option>';
            } else {
                if (empty($models)) {
                    echo '<option value="">' . esc_html__('Loading models...', 'ai-core') . '</option>';
                } else {
                    echo '<option value="">' . esc_html__('Select a model', 'ai-core') . '</option>';
                    foreach ($models as $model) {
                        $meta = \AICore\Registry\ModelRegistry::getModelConfig($model);
                        $label_text = $meta && !empty($meta['display_name']) ? $meta['display_name'] . ' (' . $model . ')' : $model;
                        echo '<option value="' . esc_attr($model) . '" ' . selected($selected_model, $model, false) . '>' . esc_html($label_text) . '</option>';
                    }
                }
            }

            echo '</select>';

            echo '<div class="ai-core-provider-params" data-provider="' . esc_attr($key) . '">';
            if (!$has_key) {
                echo '<p class="description">' . esc_html__('Add an API key to configure provider defaults.', 'ai-core') . '</p>';
            }
            echo '</div>'; // dynamic params container

            echo '</div>'; // body

            echo '<div class="ai-core-provider-card__footer">';
            echo '<button type="button" class="button-link ai-core-provider-refresh" data-provider="' . esc_attr($key) . '"' . ($has_key ? '' : ' disabled') . '>' . esc_html__('Refresh models', 'ai-core') . '</button>';
            echo '</div>';

            echo '</div>'; // card
        }

        echo '</div>';
    }
    
    /**
     * Default provider field callback
     *
     * @return void
     */
    public function default_provider_field_callback() {
        $settings = get_option($this->option_name, $this->get_default_settings());
        $value = $settings['default_provider'] ?? 'openai';

        // Get configured providers
        $api = AI_Core_API::get_instance();
        $configured_providers = $api->get_configured_providers();

        $provider_names = array(
            'openai' => 'OpenAI',
            'anthropic' => 'Anthropic Claude',
            'gemini' => 'Google Gemini',
            'grok' => 'xAI Grok'
        );

        // The Settings API renders the field title in a table header, which is
        // not an accessible name, so the control carries its own.
        echo '<select id="default_provider" aria-label="' . esc_attr__('Default provider', 'ai-core') . '" name="' . esc_attr($this->option_name) . '[default_provider]">';

        if (empty($configured_providers)) {
            echo '<option value="">' . esc_html__('-- No providers configured --', 'ai-core') . '</option>';
        } else {
            foreach ($configured_providers as $provider_key) {
                $provider_label = $provider_names[$provider_key] ?? $provider_key;
                echo '<option value="' . esc_attr($provider_key) . '" ' . selected($value, $provider_key, false) . '>';
                echo esc_html($provider_label);
                echo '</option>';
            }
        }

        echo '</select>';

        echo '<p class="description">' . esc_html__('Default AI provider for add-on plugins. Only configured providers are shown.', 'ai-core') . '</p>';
    }
    
    /**
     * Checkbox field callback
     *
     * @param array $args Field arguments
     * @return void
     */
    public function checkbox_field_callback($args) {
        $settings = get_option($this->option_name, $this->get_default_settings());
        $field = $args['field'];
        $value = $settings[$field] ?? false;
        
        echo '<label>';
        echo '<input type="checkbox" ';
        echo 'id="' . esc_attr($field) . '" ';
        echo 'name="' . esc_attr($this->option_name) . '[' . esc_attr($field) . ']" ';
        echo 'value="1" ';
        checked($value, true);
        echo '/> ';
        echo esc_html($args['label']);
        echo '</label>';
    }
    
    /**
     * Get default settings
     *
     * @return array Default settings
     */
    private function get_default_settings() {
        return array(
            'openai_api_key' => '',
            'anthropic_api_key' => '',
            'gemini_api_key' => '',
            'grok_api_key' => '',
            'default_provider' => 'openai',
            'enable_stats' => true,
            'enable_caching' => true,
            'cache_duration' => 3600,
            'persist_on_uninstall' => true,
            'provider_models' => array(),
            'provider_options' => array(),
        );
    }
    
    /**
     * Sanitize settings
     *
     * register_setting() installs this as the sanitize_option_ai_core_settings
     * filter, so it runs for the settings form AND for every programmatic
     * update_option() call, including the Clear key AJAX handler. The two
     * callers mean different things by an empty value:
     *
     * - Settings form: the key fields render empty by design, so a blank field
     *   means "leave the stored key alone".
     * - Programmatic write: the caller passes the complete settings array it
     *   wants stored, so an empty key means "remove this key".
     *
     * The form is identified by the option_page field WordPress posts to
     * options.php. That field is only read to tell the two callers apart -
     * options.php has already verified the nonce and the capability before this
     * filter runs, and nothing here grants access.
     *
     * A form can also clear a key deliberately by posting the CLEAR_SENTINEL
     * value, which always wins.
     *
     * @param array $input Raw input values
     * @return array Sanitized values
     */
    public function sanitize_settings($input) {
        $existing_settings = get_option($this->option_name, $this->get_default_settings());

        if (!is_array($input)) {
            return $existing_settings;
        }

        $sanitized = array();

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Identifies the caller only; options.php verifies the nonce first.
        $posted_page = isset($_POST['option_page']) ? sanitize_text_field(wp_unslash($_POST['option_page'])) : '';
        $is_settings_form = ($posted_page === $this->settings_group);

        // Sanitize API keys
        foreach (self::get_secret_fields() as $key) {
            $existing = $existing_settings[$key] ?? '';

            if (!array_key_exists($key, $input) || !is_string($input[$key])) {
                $sanitized[$key] = $existing;
                continue;
            }

            $new_value = sanitize_text_field($input[$key]);

            if (self::CLEAR_SENTINEL === $new_value) {
                // Explicit request to erase the key, from any caller.
                $sanitized[$key] = '';
                continue;
            }

            if ('' === $new_value) {
                $sanitized[$key] = $is_settings_form ? $existing : '';
                continue;
            }

            $sanitized[$key] = $new_value;
        }

        // Sanitize default provider
        $sanitized['default_provider'] = isset($input['default_provider']) ? sanitize_text_field($input['default_provider']) : 'openai';

        // Sanitize checkboxes
        $sanitized['enable_stats'] = isset($input['enable_stats']) && $input['enable_stats'] == '1';
        $sanitized['enable_caching'] = isset($input['enable_caching']) && $input['enable_caching'] == '1';
        $sanitized['persist_on_uninstall'] = isset($input['persist_on_uninstall']) && $input['persist_on_uninstall'] == '1';

        // Sanitize cache duration - the form has no field for it, so keep what is stored
        $sanitized['cache_duration'] = isset($input['cache_duration'])
            ? absint($input['cache_duration'])
            : absint($existing_settings['cache_duration'] ?? 3600);

        // Sanitize provider models selections.
        // The form only carries the cards on screen, so it merges over what is
        // stored. A programmatic write passes the whole array and is
        // authoritative, which is what lets the Clear path drop a provider.
        $posted_models = (isset($input['provider_models']) && is_array($input['provider_models'])) ? $input['provider_models'] : null;

        if (null === $posted_models) {
            $sanitized['provider_models'] = $existing_settings['provider_models'] ?? array();
        } else {
            $sanitized['provider_models'] = $is_settings_form ? ($existing_settings['provider_models'] ?? array()) : array();
            foreach ($posted_models as $provider => $model) {
                $provider = sanitize_key($provider);
                if (!empty($model) && is_string($model)) {
                    $sanitized['provider_models'][$provider] = sanitize_text_field($model);
                } else {
                    unset($sanitized['provider_models'][$provider]);
                }
            }
        }

        // Sanitize provider-specific parameter values
        $posted_options = (isset($input['provider_options']) && is_array($input['provider_options'])) ? $input['provider_options'] : null;

        if (null === $posted_options) {
            $sanitized['provider_options'] = $existing_settings['provider_options'] ?? array();
        } else {
            $sanitized['provider_options'] = $is_settings_form ? ($existing_settings['provider_options'] ?? array()) : array();

            foreach ($posted_options as $provider => $options) {
                $provider = sanitize_key($provider);

                if (!is_array($options)) {
                    continue;
                }

                $model = $sanitized['provider_models'][$provider] ?? ($existing_settings['provider_models'][$provider] ?? '');
                $schema = ($model && class_exists('\\AICore\\Registry\\ModelRegistry'))
                    ? \AICore\Registry\ModelRegistry::getParameterSchema($model)
                    : array();

                $clean = array();

                foreach ($schema as $param_key => $meta) {
                    if (isset($options[$param_key])) {
                        $clean[$param_key] = $this->sanitize_parameter_value($options[$param_key], $meta);
                    } elseif (isset($meta['default'])) {
                        $clean[$param_key] = $meta['default'];
                    }
                }

                // A model the registry does not describe still has values the
                // user typed. Keep them rather than dropping them on the floor,
                // otherwise the fields vanish on the next page load.
                foreach ($options as $param_key => $param_value) {
                    $param_key = sanitize_key($param_key);
                    if (isset($clean[$param_key]) || is_array($param_value)) {
                        continue;
                    }
                    $clean[$param_key] = $this->sanitize_parameter_value($param_value, array());
                }

                $sanitized['provider_options'][$provider] = $clean;
            }
        }

        return $sanitized;
    }

    /**
     * Sanitize individual model parameter values based on metadata.
     *
     * @param mixed $value
     * @param array $meta
     * @return mixed
     */
    private function sanitize_parameter_value($value, array $meta) {
        switch ($meta['type'] ?? '') {
            case 'number':
                $value = is_numeric($value) ? $value : ($meta['default'] ?? 0);
                $min = $meta['min'] ?? null;
                $max = $meta['max'] ?? null;
                if ($min !== null && $value < $min) {
                    $value = $min;
                }
                if ($max !== null && $value > $max) {
                    $value = $max;
                }
                if (isset($meta['step']) && $meta['step'] < 1) {
                    return (float) $value;
                }
                return (int) $value;
            case 'select':
                $valid = array_column($meta['options'] ?? [], 'value');
                return in_array($value, $valid, true) ? $value : ($meta['default'] ?? reset($valid));
            default:
                return sanitize_text_field($value);
        }
    }
    
    /**
     * Get setting value
     *
     * @param string $key Setting key
     * @param mixed $default Default value
     * @return mixed Setting value
     */
    public function get_setting($key, $default = null) {
        $settings = get_option($this->option_name, $this->get_default_settings());
        return $settings[$key] ?? $default;
    }

    /**
     * Register the option-level hooks that keep API keys encrypted at rest.
     *
     * These run on every request, admin or not, because add-ons read the keys
     * through get_option() from the front end and from cron as well.
     *
     * Compatibility contract: the keys are ciphertext in the database and
     * plaintext everywhere else. Anything reading get_option('ai_core_settings')
     * - AI-Core itself, AI-Scribe's get_hub_api_key(), any other add-on - keeps
     * receiving a usable key and needs no change. Only a direct SQL read sees
     * the ciphertext.
     *
     * @return void
     */
    public static function bootstrap() {
        add_filter('option_' . self::OPTION_NAME, array(__CLASS__, 'decrypt_settings_option'));
        // Priority 20 so this runs after the registered sanitize callback.
        add_filter('sanitize_option_' . self::OPTION_NAME, array(__CLASS__, 'encrypt_settings_option'), 20);
        add_action('plugins_loaded', array(__CLASS__, 'maybe_migrate_key_storage'), 5);
    }

    /**
     * Decrypt secret fields as the option is read.
     *
     * @param mixed $settings Stored settings
     * @return mixed Settings with plaintext keys
     */
    public static function decrypt_settings_option($settings) {
        if (!is_array($settings)) {
            return $settings;
        }

        foreach (self::get_secret_fields() as $field) {
            if (isset($settings[$field]) && is_string($settings[$field]) && '' !== $settings[$field]) {
                $settings[$field] = self::decrypt_value($settings[$field]);
            }
        }

        return $settings;
    }

    /**
     * Encrypt secret fields as the option is written.
     *
     * @param mixed $settings Settings about to be stored
     * @return mixed Settings with encrypted keys
     */
    public static function encrypt_settings_option($settings) {
        if (!is_array($settings)) {
            return $settings;
        }

        foreach (self::get_secret_fields() as $field) {
            if (isset($settings[$field]) && is_string($settings[$field]) && '' !== $settings[$field]) {
                $settings[$field] = self::encrypt_value($settings[$field]);
            }
        }

        return $settings;
    }

    /**
     * One-time migration of plaintext keys already in the database.
     *
     * Reads through the decrypt filter (which passes unprefixed plaintext
     * straight through) and writes back through the encrypt filter.
     *
     * @return void
     */
    public static function maybe_migrate_key_storage() {
        if (get_option(self::ENCRYPTION_OPTION) === self::ENCRYPTION_VERSION) {
            return;
        }

        $settings = get_option(self::OPTION_NAME, null);

        if (is_array($settings)) {
            update_option(self::OPTION_NAME, $settings);
        }

        update_option(self::ENCRYPTION_OPTION, self::ENCRYPTION_VERSION);
    }

    /**
     * Encrypt a single secret with AES-256-CBC and a random per-value IV.
     *
     * @param string $value Plaintext secret
     * @return string Versioned ciphertext, or the plaintext if OpenSSL is unavailable
     */
    private static function encrypt_value($value) {
        if ('' === $value || 0 === strpos($value, self::ENCRYPTION_PREFIX)) {
            return $value;
        }

        if (!function_exists('openssl_encrypt') || !function_exists('openssl_random_pseudo_bytes')) {
            return $value;
        }

        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($value, 'AES-256-CBC', self::get_encryption_key(), 0, $iv);

        if (false === $encrypted) {
            return $value;
        }

        return self::ENCRYPTION_PREFIX . base64_encode($iv . $encrypted);
    }

    /**
     * Decrypt a single secret.
     *
     * Fails closed: a marked ciphertext that will not decrypt (the salts have
     * changed, say) returns an empty string rather than leaking stored bytes.
     *
     * @param string $value Stored value
     * @return string Plaintext secret
     */
    private static function decrypt_value($value) {
        if (0 !== strpos($value, self::ENCRYPTION_PREFIX)) {
            // Predates the migration: still plaintext.
            return $value;
        }

        $decoded = base64_decode(substr($value, strlen(self::ENCRYPTION_PREFIX)), true);

        if (false === $decoded || strlen($decoded) <= 16 || !function_exists('openssl_decrypt')) {
            return '';
        }

        $decrypted = openssl_decrypt(
            substr($decoded, 16),
            'AES-256-CBC',
            self::get_encryption_key(),
            0,
            substr($decoded, 0, 16)
        );

        return false !== $decrypted ? $decrypted : '';
    }

    /**
     * Derive the 32-byte encryption key from the WordPress salts.
     *
     * @return string Binary key
     */
    private static function get_encryption_key() {
        $salt_data  = defined('AUTH_SALT') ? AUTH_SALT : 'ai-core-auth';
        $salt_data .= defined('SECURE_AUTH_SALT') ? SECURE_AUTH_SALT : 'ai-core-secure';
        $salt_data .= defined('LOGGED_IN_SALT') ? LOGGED_IN_SALT : 'ai-core-logged';
        $salt_data .= defined('NONCE_SALT') ? NONCE_SALT : 'ai-core-nonce';

        return hash('sha256', $salt_data . 'ai-core-encryption-key', true);
    }
}

// Keys are encrypted at rest and decrypted on read for every request.
AI_Core_Settings::bootstrap();
